// Função para redirecionar para a página específica
function redirectToPage(pageUrl) {
    window.location.href = pageUrl;
}